#!/bin/sh
npm install bower -g